function ExecuteScript(strId)
{
  switch (strId)
  {
      case "5i0xCri53wv":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

